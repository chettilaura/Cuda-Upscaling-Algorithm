#include <stdio.h>
#include <stdlib.h>
//#include <helper_cuda.h>
#include <string>
